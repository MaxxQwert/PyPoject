import re
import sys

for line in sys.stdin:
    repl = r'\1'
    pattern = r'(\w)\1+'
    a = re.search(pattern, line)
    line = re.sub(pattern, repl, line)
    print(line.strip())
    print(a)
