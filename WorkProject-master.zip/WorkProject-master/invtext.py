with open('dataset_24465_4.txt', 'r') as r, open('output.txt', 'w') as w:
    l = r.read().splitlines()
    wl = '\n'.join(l[::-1])
    w.write(wl)
