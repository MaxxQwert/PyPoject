s = input()
t = input()
i = 0
k = 0
while k + len(t) <= len(s):
    k = s.find(t, k)
    i += 1
    k = k + 1
print(i)
