s = input()
a = input()
b = input()
s_temp = ''
i = 0
for _ in range(1001):
    if a in s:
        s = s.replace(a, b)
        i += 1
if i <= 1000:
    print(i, s)
else:
    print('Impossible', i)