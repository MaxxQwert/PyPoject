def mod_checker(x, mod=0):
    return lambda y: y % x == mod
lower = 0
offset = 1
upper = 5
step = 1
a = [i for i in range(21)]

s = mod_checker(3)
print(s(3))

b = a[lower + offset:upper + offset]

b1 = a[lower : : upper]

b2 = a[lower+offset : upper+offset]

b3 = a[lower + offset : upper + offset]

b4 = a[lower:upper], a[lower:upper:], a[lower::step]
