import itertools

def primes():
    a = 1
    while True:  # просто пример
        if a % 2 == 0:
            yield a
        a += 1


print(list(itertools.takewhile(lambda x : x <= 31, primes())))
pass