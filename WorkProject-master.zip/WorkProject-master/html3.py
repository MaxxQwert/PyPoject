import requests
import re


def ref_ex(url):
    refs = re.findall(r'<a.*href\s*?=\s*?[\"\'](\w*?://)?(.*?)[/:\?].*[\"\']', requests.get(url).text)
    return refs

refs = {}
url = input()
refs = sorted(list(set(ref_ex(url))))
for i in refs:
    print(i)

# https://stepic.org/media/attachments/lesson/24472/sample0.html
#https://pastebin.com/raw/hfMThaGb
#[/:\?]