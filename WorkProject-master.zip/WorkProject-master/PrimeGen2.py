import itertools

def primes():
    fuca = 1
    p = 2
    while True:
        fuca *= (p-1)
        if (fuca+1) % p == 0:
            yield p
        p += 1



print(list(itertools.takewhile(lambda x : x <= 310, primes())))
pass