import re
import sys

for line in sys.stdin:
    if len(re.findall(r'cat', line.rstrip().lower())) >= 2:
        print(line.strip())
