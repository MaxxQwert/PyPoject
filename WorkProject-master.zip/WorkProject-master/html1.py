import requests
import re
url1, url2 = input(), input()
res = requests.get(url1)
cont = res.text
refs = re.findall(r'<a href=\"(.*?)\"', cont)
for ref in refs:
    res2 = requests.get(ref)
    cont2 = res2.text
    refs2 = re.findall(r'<a href=\"(.*?)\"', cont)
print(refs, refs2)

#https://stepic.org/media/attachments/lesson/24472/sample0.html