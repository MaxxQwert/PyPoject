def primes(n):
    fuca = 1
    p = 2
    while p <= n:
        fuca *= (p - 1)
        if (fuca + 1) % p == 0:
            yield p
        p += 1


for i in primes(50):
    print(i, end=' ')
pass