s, t = input(), input()
i = 0
while t in s:
    s = s[s.find(t)+1:]
    i += 1
print(i)
