import requests
import re


def ref_ex(url):
    refs = re.findall(r'<a href=\"(.*?)\"', requests.get(url).text)
    return refs


fl = True
url1, url2 = input(), input()
refs = ref_ex(url1)
for ref in refs:
    refs2 = ref_ex(ref)
    if url2 in refs2:
        print('Yes')
        fl = False
        break
if fl:
    print('No')
print(refs)
print(requests.get(url1).text)

# https://stepic.org/media/attachments/lesson/24472/sample0.html
