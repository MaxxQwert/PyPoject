a = 'hello world'
b = [1,2,3,5,6,4]
print(a)
c = {'a':[3,5,6], 'b':['d','g']}
print(c)
pass